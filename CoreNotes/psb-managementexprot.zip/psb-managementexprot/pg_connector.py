"""
Модуль, при поиощи которого осуществляется  соединение с БД
"""
import os
from configparser import ConfigParser
import psycopg

# Определяю персональные пути, для более удобной работы из дома и на работе

win_dir = rf'{os.getcwd()}/settings.ini'
db_section = 'postgresql_prod'

def connect():
    """
    connect Функция создающая соединение с БД. При помощи данных из конфига, 
    в котором находятся креды.
    Таже, внутри функции создается переменная conn, 
    при помощи которой будет создаваться курсор, а так же 
    закрываться соединение с БД.
    
    """
    try:
        global conn
        # Считываем параметры соединения из конфига
        params = config(win_dir)

        # Соединение с БД
        print('Подключение к %s', db_section)
        conn = psycopg.connect(**params)
        print('Подключение успешно')

        # Прокидываем исключения
    except (RuntimeError) as error:
        print(error)



def config(filepath, section= db_section):
    """
    config Функция, парсящая конфиг с раширение .ini, в котоом находятся креды для соединия с БД.

    Args:
        filepath (str): Строка в которой прописан путь к .ini файлу. 
        section (str): Название секции внутри .ini файла, 
        из которой будут браться данные для покдлючения к БД. 

    Raises:
        Exception: Исключение, возвращающее название секции и файла,
        в котором скрипт пытался найти данную функцию.

    Returns:
        db (dict): Словарь, в котором запсаны основные креды для покдлючения к БД
    """
    parser = ConfigParser()
    parser.read(filepath)

    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise RuntimeError (f'Секция {section} не найдена в файле {filepath} .')
    return db

connect()
