import openpyxl as op
import math
import os
import sys
from datetime import datetime, timedelta
import pandas as pd
import pg_connector as pg

pg.connect()
cur = pg.conn.cursor()

start_date = os.getenv("START_DATE")
end_date = os.getenv("END_DATE")

if not start_date or not end_date:
    print("Error: Please set START_DATE and END_DATE environment variables")
    sys.exit(1)

output_dir = "/app/output"
os.makedirs(output_dir, exist_ok=True)

# Сохраняем файл


_FILE_NAME = f"Учет в промежутке {start_date} - {end_date}.xlsx"

file_path = os.path.join(output_dir, f"{_FILE_NAME}.xlsx")

def create_xlsx():
    """
    create_xlsx Функция генерирующая шаблон отчета времени

    ### Returns:
       - wb: XLSX документ
    """
    wb = op.Workbook()
    ws = wb.active
    ws.title = "Учет времени"
    ws.append(["Инженер", "Начало миграции", "Конец миграции", "Учет времени", \
        "Переработка", "Выходной день", "X1.5", "X2", "X2 Выходной"])
    wb.save(file_path)

    print(f"Файл '{_FILE_NAME}' успешно создан.")
    return _FILE_NAME

def count_whole_hours_in_range(start_str, end_str):
    start = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
    end = datetime.strptime(end_str, "%Y-%m-%d %H:%M:%S")

    # Устанавливаем границы периода
    evening_start = start.replace(hour=18, minute=0, second=0)
    evening_end = start.replace(hour=20, minute=0, second=0)

    # Если конец раньше начала, корректируем границы
    if end < evening_start or start > evening_end:
        return 0  # Нет пересечений

    # Определяем фактическое время начала и окончания в диапазоне
    actual_start = max(start, evening_start)
    actual_end = min(end, evening_end)

    # Подсчитываем количество полных часов в диапазоне и округляем вверх
    total_seconds = (actual_end - actual_start).total_seconds()
    full_hours = math.ceil(total_seconds / 3600)

    return full_hours



def insert_to_excel(_FILE_NAME, start_date, end_date):
    
    wb = op.load_workbook(file_path)
    ws = wb.active
    cur.execute(f'''select "Инженеры"."ФИО", "Start", "End", "WorktimeHours",
                "OvertimeHours", "Weekend" from "Учет времени"
                LEFT join "Инженеры" ON "Инженеры".id_engineer = "Учет времени".engineer_id
                Where "Start" >= \'{start_date}\'
                AND "Start" <= \'{end_date}\'''')
    select_result = cur.fetchall()
    
    
    # Обрабатываем и добавляем данные с изменением времени
    for result in select_result:
        engineer = result[0]
        start = str(result[1])
        end = str(result[2])
        uchet_vremeni = result[3]
        overtime = result[4]
        weekend = result[5]

        print(result)
        # Обработка пустых строк
        if engineer is None:
            continue
        # Преобразуем строки в datetime объекты и добавляем 3 часа
        else:
            try:
                start_dt = datetime.strptime(start, '%Y-%m-%d %H:%M:%S') + timedelta(hours=3)
                start_str = start_dt.strftime('%Y-%m-%d %H:%M:%S')
            except ValueError:
                start_str = None
            try:
                end_dt = datetime.strptime(end, '%Y-%m-%d %H:%M:%S') + timedelta(hours=3)
                end_str = end_dt.strftime('%Y-%m-%d %H:%M:%S')
            except ValueError:
                end_str = None
            # Добавляем строки в Excel для расчета ставки преработок
            if weekend is True and overtime <= 8:
                ws.append([engineer, start_str, end_str, uchet_vremeni, overtime, weekend, 0, 0, 8])
            elif weekend  is True and overtime > 8:
                ws.append([engineer, start_str, end_str, uchet_vremeni, overtime, weekend, 0, 0, overtime])

            else:
                lovt = count_whole_hours_in_range(start_str, end_str)
                ws.append([engineer, start_str, end_str, uchet_vremeni, overtime, weekend, lovt, overtime-lovt, 0])

        
    wb.save(file_path)

    print(f"Файл '{_FILE_NAME}' успешно создан.")

def sum_overtimes(_FILE_NAME):

    # Открываем Excel-файл
    xls = pd.ExcelFile(file_path)

    # Читаем основной лист (назовем его 'Основной')
    df = pd.read_excel(xls, 'Учет времени')

    # Извлекаем уникальные имена сотрудников
    unique_names = df['Инженер'].unique()

    # Создаем новый DataFrame для результирующего листа
    result_df = pd.DataFrame(unique_names, columns=['Инженер'])

    # Создаем столбцы для суммирования значений
    result_df['X1.5'] = 0
    result_df['X2'] = 0
    result_df['X2 Выходной'] = 0

    # Суммируем значения для каждого сотрудника
    for name in unique_names:
        mask = df['Инженер'] == name
        result_df.loc[result_df['Инженер'] == name, 'X1.5'] = df.loc[mask, 'X1.5'].sum()
        result_df.loc[result_df['Инженер'] == name, 'X2'] = df.loc[mask, 'X2'].sum()
        result_df.loc[result_df['Инженер'] == name, 'X2 Выходной'] = df.loc[mask, 'X2 Выходной'].sum()

    # Создаем новый лист "Общие переработки"
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        result_df.to_excel(writer, sheet_name='Общие переработки', index=False)

    print("Данные успешно обработаны и записаны.")



if __name__ == '__main__':
    
    insert_to_excel(create_xlsx(), start_date, end_date)
    sum_overtimes(file_path)
